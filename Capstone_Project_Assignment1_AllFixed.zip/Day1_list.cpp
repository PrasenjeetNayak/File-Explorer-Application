#include <iostream>
#include <dirent.h>
#include <cstring>
using namespace std;
int main() {
    string path;
    cout << "Enter directory path: ";
    cin >> path;
    DIR* dir = opendir(path.c_str());
    if (!dir) { cout << "Cannot open directory\n"; return 1; }
    struct dirent* entry;
    cout << "Contents of " << path << ":\n";
    while ((entry = readdir(dir)) != nullptr) cout << entry->d_name << '\n';
    closedir(dir);
    return 0;
}