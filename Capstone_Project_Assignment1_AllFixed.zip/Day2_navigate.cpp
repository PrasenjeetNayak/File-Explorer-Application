#include <iostream>
#include <unistd.h>
#include <limits.h>
using namespace std;
int main() {
    char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) == nullptr) { cout << "Error\n"; return 1; }
    string cmd;
    while (true) {
        cout << "Current: " << cwd << "\n";
        cout << "Enter directory to change to (.. to go up, exit to quit): ";
        cin >> cmd;
        if (cmd == "exit") break;
        if (chdir(cmd.c_str()) == 0) {
            if (getcwd(cwd, sizeof(cwd)) == nullptr) { cout << "Error\n"; return 1; }
        } else cout << "Invalid directory\n";
    }
    return 0;
}