#include <iostream>
#include <fstream>
#include <cstdio>
using namespace std;
int main() {
    int choice;
    string a,b;
    while (true) {
        cout << "1.Create 2.Delete 3.Copy 4.Move 5.Exit\n";
        cin >> choice;
        if (choice==1) { cout << "Filename: "; cin >> a; ofstream f(a); f.close(); cout << "Created\n"; }
        else if (choice==2) { cout << "Filename: "; cin >> a; if (remove(a.c_str())==0) cout << "Deleted\n"; else cout << "Failed\n"; }
        else if (choice==3) { cout << "Source: "; cin >> a; cout << "Destination: "; cin >> b; ifstream in(a, ios::binary); ofstream out(b, ios::binary); out << in.rdbuf(); cout << "Copied\n"; }
        else if (choice==4) { cout << "Source: "; cin >> a; cout << "Destination: "; cin >> b; if (rename(a.c_str(), b.c_str())==0) cout << "Moved\n"; else cout << "Failed\n"; }
        else break;
    }
    return 0;
}