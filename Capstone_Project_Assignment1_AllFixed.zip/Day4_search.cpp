#include <iostream>
#include <dirent.h>
#include <cstring>
using namespace std;
void search(const string& path, const string& name) {
    DIR* dir = opendir(path.c_str());
    if (!dir) return;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        string d = entry->d_name;
        if (d == "." || d == "..") continue;
        string full = path + "/" + d;
        if (entry->d_type == DT_DIR) search(full, name);
        else if (d.find(name) != string::npos) cout << "Found: " << full << '\n';
    }
    closedir(dir);
}
int main() {
    string path,name;
    cout << "Start path: "; cin >> path;
    cout << "Search name: "; cin >> name;
    search(path,name);
    return 0;
}