#include <iostream>
#include <sys/stat.h>
using namespace std;
int main() {
    string fname;
    int perm;
    cout << "Filename: "; cin >> fname;
    cout << "Octal permission (e.g. 755): "; cin >> oct >> perm;
    if (chmod(fname.c_str(), perm) == 0) cout << "Permission changed\n"; else cout << "Failed\n";
    return 0;
}