#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#include <cstring>
#include <vector>
#include <fstream>
#include <cstdlib>
using namespace std;
void listFiles(const string& path) {
    DIR* dir;
    struct dirent* entry;
    if ((dir = opendir(path.c_str())) != nullptr) {
        cout << "\nContents of " << path << ":\n";
        while ((entry = readdir(dir)) != nullptr) cout << entry->d_name << endl;
        closedir(dir);
    } else cout << "Cannot open directory\n";
}
void changeDirectory(string& currentPath) {
    string dir;
    cout << "Enter directory name: ";
    cin >> dir;
    string newPath = currentPath + "/" + dir;
    if (chdir(newPath.c_str()) == 0) {
        char buffer[PATH_MAX];
        getcwd(buffer, PATH_MAX);
        currentPath = buffer;
        cout << "Changed to " << currentPath << endl;
    } else cout << "Invalid directory\n";
}
void createFile() {
    string filename;
    cout << "Enter new file name: ";
    cin >> filename;
    ofstream file(filename);
    if (file) cout << "File created successfully\n"; else cout << "Failed to create file\n";
}
void deleteFile() {
    string filename;
    cout << "Enter file name to delete: ";
    cin >> filename;
    if (remove(filename.c_str()) == 0) cout << "File deleted\n"; else cout << "Failed to delete file\n";
}
void copyFile() {
    string src, dest;
    cout << "Source file: ";
    cin >> src;
    cout << "Destination file: ";
    cin >> dest;
    ifstream in(src, ios::binary);
    ofstream out(dest, ios::binary);
    out << in.rdbuf();
    cout << "File copied\n";
}
void moveFile() {
    string src, dest;
    cout << "Source file: ";
    cin >> src;
    cout << "Destination: ";
    cin >> dest;
    if (rename(src.c_str(), dest.c_str()) == 0) cout << "File moved\n"; else cout << "Failed to move file\n";
}
void searchFile(const string& path, const string& name) {
    DIR* dir;
    struct dirent* entry;
    if ((dir = opendir(path.c_str())) != nullptr) {
        while ((entry = readdir(dir)) != nullptr) {
            if (entry->d_type == DT_DIR) {
                string dname = entry->d_name;
                if (dname != "." && dname != "..") searchFile(path + "/" + dname, name);
            } else {
                if (strstr(entry->d_name, name.c_str())) cout << "Found: " << path + "/" + entry->d_name << endl;
            }
        }
        closedir(dir);
    }
}
void changePermission() {
    string filename;
    mode_t perm;
    cout << "Enter file name: ";
    cin >> filename;
    cout << "Enter octal permission (e.g. 755): ";
    cin >> oct >> perm;
    if (chmod(filename.c_str(), perm) == 0) cout << "Permission changed\n"; else cout << "Failed to change permission\n";
}
int main() {
    string currentPath;
    char buffer[PATH_MAX];
    getcwd(buffer, PATH_MAX);
    currentPath = buffer;
    int choice;
    while (true) {
        cout << "\n===== File Explorer Menu =====\n";
        cout << "1. List Files\n2. Change Directory\n3. Create File\n4. Delete File\n5. Copy File\n6. Move File\n7. Search File\n8. Change Permission\n9. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        switch (choice) {
            case 1: listFiles(currentPath); break;
            case 2: changeDirectory(currentPath); break;
            case 3: createFile(); break;
            case 4: deleteFile(); break;
            case 5: copyFile(); break;
            case 6: moveFile(); break;
            case 7: {string name; cout << "Enter name to search: "; cin >> name; searchFile(currentPath, name);} break;
            case 8: changePermission(); break;
            case 9: cout << "Exiting...\n"; exit(0);
            default: cout << "Invalid choice\n";
        }
    }
}